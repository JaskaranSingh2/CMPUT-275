#include <iostream>

int main() {
    std::cout << "I enjoyed learning about memory management and why and how it gives more control than garbage collected languages" << std::endl;
    std::cout << "The ability to create efficient data structures in C++ is pretty interesting" << std::endl;
    std::cout << "I enjoyed learning pointers and references, which helped me become a better programmer overall" << std::endl;
    
    return 0;
}